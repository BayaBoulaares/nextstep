// app/dashboard/services/deploy/recapitulatif/page.tsx
"use client"

import * as React from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { Separator } from "@/components/ui/separator"
import { Button }    from "@/components/ui/button"
import { Loader2, AlertTriangle } from "lucide-react"
import { Stepper }   from "@/components/deploy/stepper"
import { loadDraft, useDeploymentTunnel } from "@/lib/hooks/useDeployments"
import { getServiceById } from "@/lib/services/cloud-services.api"
import type { CloudServiceDTO, PlanDTO, DeploymentRequest } from "@/lib/types"
import { cn } from "@/lib/utils"

const STEPS = [
  { id: 1, label: "Sélection du plan" },
  { id: 2, label: "Configuration"     },
  { id: 3, label: "Récapitulatif"     },
  { id: 4, label: "Déploiement"       },
]

// ✅ Helper : calcule les specs depuis vcores/ramGb/storageGb
// PlanDTO.java n'a PAS de champ "specs" — il ne faut jamais utiliser plan.specs
function planSpecs(plan: PlanDTO): string {
  return [
    plan.vcores    ? `${plan.vcores} vCPU`  : "",
    plan.ramGb     ? `${plan.ramGb} Go RAM` : "",
    plan.storageGb ? `${plan.storageGb} Go SSD` : "",
  ].filter(Boolean).join(" · ") || "—"
}

// ── Section tableau ───────────────────────────────────────────────────────────

function RecapSection({ title, rows }: {
  title: string
  rows:  { label: string; value: React.ReactNode }[]
}) {
  return (
    <div>
      <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-muted-foreground mb-2">
        {title}
      </p>
      <div className="border border-border rounded-xl overflow-hidden divide-y divide-border">
        {rows.map((row, i) => (
          <div key={i} className="flex items-center justify-between px-5 py-3 bg-card">
            <span className="text-[13px] text-muted-foreground">{row.label}</span>
            <span className="text-[13px] font-medium text-right">{row.value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function RecapPage() {
  const router = useRouter()
  const { confirm, loading, error } = useDeploymentTunnel()

  const [service,  setService]  = React.useState<CloudServiceDTO | null>(null)
  const [plan,     setPlan]     = React.useState<PlanDTO | null>(null)
  const [draft,    setDraft]    = React.useState<Partial<DeploymentRequest> | null>(null)
  const [fetching, setFetching] = React.useState(true)

  React.useEffect(() => {
    const d = loadDraft()
    setDraft(d)
    if (!d?.serviceId) { setFetching(false); return }
    getServiceById(d.serviceId)
      .then(svc => {
        setService(svc)
        const p = svc.plans.find(p => p.id === d.planId) ?? svc.plans[0]
        setPlan(p ?? null)
      })
      .finally(() => setFetching(false))
  }, [])

  const handleConfirm = async () => {
    if (!draft || !service || !plan) return
    const deployment = await confirm(draft as DeploymentRequest)
    router.push(`/dashboard/services/deploy/deploiement?id=${deployment.id}`)
  }

  const ht    = plan?.price ?? 0
  const tva   = ht * 0.2
  const total = ht + tva

  if (fetching) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="size-4 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <SidebarInset>

      <header className="flex h-14 items-center gap-3 border-b border-border/60 px-5 bg-background/95 backdrop-blur sticky top-0 z-10">
        <SidebarTrigger className="-ml-1 size-8 text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors" />
        <Separator orientation="vertical" className="h-4 opacity-40" />
        <nav className="flex items-center gap-1.5 text-[12px] text-muted-foreground">
          <Link href="/dashboard/services" className="hover:text-foreground transition-colors">Marketplace</Link>
          <span className="opacity-30">/</span>
          <span>Configuration</span>
          <span className="opacity-30">/</span>
          <span className="font-medium text-foreground">Récapitulatif</span>
        </nav>
      </header>

      <div className="border-b border-border/60 px-5 py-3 bg-background">
        <Stepper steps={STEPS} current={3} />
      </div>

      <div className="p-6 max-w-2xl mx-auto w-full">
        <div className="mb-8">
          <h1 className="text-xl font-semibold tracking-tight">Récapitulatif de commande</h1>
          <p className="text-[13px] text-muted-foreground mt-1">
            Vérifiez votre configuration avant de confirmer le déploiement.
          </p>
        </div>

        <div className="space-y-6">

          <RecapSection
            title="Service commandé"
            rows={[
              { label: "Service",       value: `${service?.icon ?? ""} ${service?.name ?? "—"}` },
              { label: "Type de cloud", value: service?.cloudType ?? "—" },
              { label: "Plan",          value: plan?.name ?? "—" },
              { label: "Nom ressource", value: <span className="font-mono text-[12px]">{draft?.name ?? "—"}</span> },
              { label: "Projet",        value: draft?.projectName ?? "—" },
            ]}
          />

          <RecapSection
            title="Configuration technique"
            rows={[
              // ✅ planSpecs() à la place de plan?.specs (champ inexistant dans PlanDTO.java)
              { label: "Specs",         value: plan ? planSpecs(plan) : "—"      },
              { label: "Stockage add.", value: `${draft?.storageGb ?? 0} Go`     },
              { label: "OS",            value: draft?.os ?? "—"                  },
              { label: "Région / Zone", value: `${draft?.region ?? "—"} — ${draft?.zone ?? "—"}` },
              { label: "VPC",           value: draft?.vpcId ?? "—"               },
            ]}
          />

          <RecapSection
            title="Options activées"
            rows={[
              { label: "Backup",     value: draft?.options?.backup     ? "✓ Activé" : "— Non activé" },
              { label: "Monitoring", value: draft?.options?.monitoring  ? "✓ Activé" : "— Non activé" },
              { label: "Anti-DDoS",  value: draft?.options?.ddos       ? "✓ Activé" : "— Non activé" },
              { label: "SSH Keys",   value: draft?.options?.ssh        ? "✓ Activé (inclus)" : "— Non activé" },
            ]}
          />

          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-muted-foreground mb-2">
              Détail tarifaire
            </p>
            <div className="border border-border rounded-xl overflow-hidden divide-y divide-border">
              {[
                { label: `Plan ${plan?.name ?? ""}`, price: `${ht.toFixed(2)} €`,     bold: false },
                { label: "Sous-total HT",             price: `${ht.toFixed(2)} €`,     bold: false },
                { label: "TVA (20%)",                 price: `+${tva.toFixed(2)} €`,   bold: false },
                { label: "Total TTC / mois",          price: `${total.toFixed(2)} €`,  bold: true  },
              ].map((line, i) => (
                <div key={i} className={cn(
                  "flex items-center justify-between px-5 py-3 bg-card",
                  line.bold && "font-semibold"
                )}>
                  <span className={cn("text-[13px]", line.bold ? "text-foreground" : "text-muted-foreground")}>
                    {line.label}
                  </span>
                  <span className={cn("text-[13px] tabular-nums", line.bold && "text-base")}>
                    {line.price}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-start gap-2.5 border border-amber-200 bg-amber-50 rounded-xl px-4 py-3">
            <span className="shrink-0 mt-0.5">⚠️</span>
            <p className="text-[12px] text-amber-800 leading-relaxed">
              En confirmant, vous acceptez les Conditions Générales de Service et la Politique de facturation.
              La première facture sera émise à la date de déploiement.
            </p>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-[12px] text-red-600">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />{error}
            </div>
          )}

          <div className="flex items-center gap-3 pt-2">
            <Button variant="outline" className="h-9 text-[13px]" onClick={() => router.back()}>
              ← Modifier la configuration
            </Button>
            <Button
              className="flex-1 h-9 text-[13px] font-medium"
              onClick={handleConfirm}
              disabled={loading || !plan}
            >
              {loading
                ? <><Loader2 className="w-3.5 h-3.5 mr-2 animate-spin" />Création…</>
                : "✓ Confirmer et déployer"
              }
            </Button>
          </div>

        </div>
      </div>
    </SidebarInset>
  )
}