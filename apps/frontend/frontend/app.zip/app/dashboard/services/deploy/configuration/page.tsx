//app/dashboard/services/deploy/configuration/page.tsx
"use client"

import * as React from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { Separator } from "@/components/ui/separator"
import { Button }    from "@/components/ui/button"
import { Input }     from "@/components/ui/input"
import { Label }     from "@/components/ui/label"
import { Switch }    from "@/components/ui/switch"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Stepper }   from "@/components/deploy/stepper"
import { cn }        from "@/lib/utils"

// ── Données ───────────────────────────────────────────────────────────────────

const STEPS = [
  { id: 1, label: "Sélection du plan" },
  { id: 2, label: "Configuration"     },
  { id: 3, label: "Récapitulatif"     },
  { id: 4, label: "Déploiement"       },
]

const DATACENTERS = [
  { id: "paris",    label: "Paris",     flag: "🇫🇷", sub: "DC1 · EU-WEST"    },
  { id: "francfort",label: "Francfort", flag: "🇩🇪", sub: "DC2 · EU-CENTRAL" },
  { id: "london",   label: "Londres",   flag: "🇬🇧", sub: "DC3 · EU-NORTH"   },
]

const ZONES = [
  { id: "a",     label: "Zone A",     sub: "Capacité élevée"  },
  { id: "b",     label: "Zone B",     sub: "Capacité normale" },
  { id: "multi", label: "Multi-zone", sub: "HA automatique"   },
]

const OS_LIST = [
  { id: "ubuntu", label: "Ubuntu 24.04 LTS", sub: "Recommandé",      flag: "🐧" },
  { id: "rocky",  label: "Rocky Linux 9",    sub: "RHEL-compatible",  flag: "🐧" },
  { id: "debian", label: "Debian 12",        sub: "Stable",           flag: "🐧" },
  { id: "win",    label: "Windows Server 2022", sub: "+45€/mois",     flag: "🪟" },
]

const OPTIONS = [
  { id: "backup",    label: "Backup automatique quotidien",  sub: "Snapshot NVMe chaque nuit, rétention 30 jours", price: "+19 €/mois", default: true  },
  { id: "monitoring",label: "Monitoring & Alertes",          sub: "CPU, RAM, disque, réseau — alertes SMS/email",  price: "+9 €/mois",  default: true  },
  { id: "ddos",      label: "Anti-DDoS avancé",             sub: "Protection volumétrique jusqu'à 500 Gbps",      price: "+29 €/mois", default: false },
  { id: "ssh",       label: "Gestion des clés SSH",         sub: "Coffre-fort de clés et rotation automatique",   price: "Inclus",     default: true  },
]

// ── Composants réutilisables ──────────────────────────────────────────────────

function SectionCard({
  icon,
  title,
  sub,
  children,
}: {
  icon: string
  title: string
  sub: string
  children: React.ReactNode
}) {
  return (
    <div className="border border-border rounded-2xl overflow-hidden">
      <div className="flex items-center gap-3 px-6 py-4 border-b border-border bg-muted/20">
        <span className="text-lg">{icon}</span>
        <div>
          <p className="text-[13px] font-semibold text-foreground">{title}</p>
          <p className="text-[11px] text-muted-foreground">{sub}</p>
        </div>
      </div>
      <div className="px-6 py-5 space-y-5 bg-card">{children}</div>
    </div>
  )
}

function PickerGrid<T extends { id: string; label: string; sub: string; flag?: string }>({
  items,
  value,
  onChange,
}: {
  items: T[]
  value: string
  onChange: (v: string) => void
}) {
  return (
    <div className="grid grid-cols-3 gap-2">
      {items.map(item => (
        <button
          key={item.id}
          onClick={() => onChange(item.id)}
          className={cn(
            "text-left p-3 rounded-xl border text-[12px] transition-all",
            value === item.id
              ? "border-foreground bg-foreground/5 font-medium"
              : "border-border hover:border-foreground/30 hover:bg-muted/40"
          )}
        >
          <span className="flex items-center gap-1.5 font-medium text-foreground">
            {item.flag && <span>{item.flag}</span>}
            {item.label}
          </span>
          <span className="text-muted-foreground text-[11px] mt-0.5 block">{item.sub}</span>
        </button>
      ))}
    </div>
  )
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function ConfigurationPage() {
  const router = useRouter()

  const [dc,      setDc]      = React.useState("paris")
  const [zone,    setZone]    = React.useState("a")
  const [os,      setOs]      = React.useState("ubuntu")
  const [storage, setStorage] = React.useState(500)
  const [options, setOptions] = React.useState<Record<string, boolean>>(
    Object.fromEntries(OPTIONS.map(o => [o.id, o.default]))
  )

  const basePrice  = 349
  const storageAdd = Math.round((storage - 0) / 100) * 19
  const optTotal   = OPTIONS.reduce((acc, o) => {
    if (!options[o.id]) return acc
    const n = parseInt(o.price.replace(/[^0-9]/g, ""))
    return isNaN(n) ? acc : acc + n
  }, 0)
  const total = basePrice + storageAdd + optTotal

  return (
    <SidebarInset>

      {/* ── Header ── */}
      <header className="flex h-14 items-center gap-3 border-b border-border/60 px-5 bg-background/95 backdrop-blur sticky top-0 z-10">
        <SidebarTrigger className="-ml-1 size-8 text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors" />
        <Separator orientation="vertical" className="h-4 opacity-40" />
        <nav className="flex items-center gap-1.5 text-[12px] text-muted-foreground">
          <Link href="/dashboard/services" className="hover:text-foreground transition-colors">Marketplace</Link>
          <span className="opacity-30">/</span>
          <span>Cloud Privé</span>
          <span className="opacity-30">/</span>
          <span>Compute</span>
          <span className="opacity-30">/</span>
          <span className="font-medium text-foreground">Configuration</span>
        </nav>
      </header>

      {/* ── Stepper ── */}
      <div className="border-b border-border/60 px-5 py-3 bg-background">
        <Stepper steps={STEPS} current={2} />
      </div>

      {/* ── Contenu ── */}
      <div className="flex gap-6 p-6 max-w-6xl mx-auto w-full items-start">

        {/* Colonne gauche — formulaire */}
        <div className="flex-1 min-w-0 space-y-5">

          {/* Plan sélectionné */}
          <div className="flex items-center justify-between border border-border rounded-xl px-5 py-3.5 bg-muted/20">
            <div className="flex items-center gap-3">
              <span className="text-xl">🖥️</span>
              <div>
                <p className="text-[13px] font-semibold text-foreground">vCore M — 16 vCPU · 64 Go RAM</p>
                <p className="text-[11px] text-muted-foreground">Cloud Privé · Machines Virtuelles</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-[13px] font-semibold tabular-nums">349 €/mois</span>
              <Button variant="outline" size="sm" className="h-7 text-[12px]">Changer</Button>
            </div>
          </div>

          {/* Identification */}
          <SectionCard icon="🏷️" title="Identification" sub="Nom et organisation de la ressource">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-[12px]">Nom de la VM *</Label>
                <Input defaultValue="prod-backend-01" className="h-8 text-[13px]" />
                <p className="text-[11px] text-muted-foreground">Lettres minuscules, chiffres et tirets uniquement</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px]">Projet *</Label>
                <Select defaultValue="ecommerce">
                  <SelectTrigger className="h-8 text-[13px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ecommerce">Production — E-Commerce</SelectItem>
                    <SelectItem value="staging">Staging</SelectItem>
                    <SelectItem value="dev">Dev</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[12px]">Description <span className="text-muted-foreground">(optionnel)</span></Label>
              <Input placeholder="ex: Serveur backend API principal" className="h-8 text-[13px]" />
            </div>
          </SectionCard>

          {/* Région */}
          <SectionCard icon="🌍" title="Région & Disponibilité" sub="Emplacement de déploiement">
            <div>
              <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">Datacenter</p>
              <PickerGrid items={DATACENTERS} value={dc} onChange={setDc} />
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">Zone de disponibilité</p>
              <PickerGrid items={ZONES} value={zone} onChange={setZone} />
            </div>
          </SectionCard>

          {/* Ressources */}
          <SectionCard icon="⚙️" title="Ressources supplémentaires" sub="Ajustez selon vos besoins (base incluse dans le plan)">
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-[11px] uppercase tracking-widest text-muted-foreground">Stockage additionnel (NVMe)</p>
                <span className="text-[13px] font-semibold tabular-nums">{storage} Go</span>
              </div>
              <input
                type="range" min={0} max={2000} step={100}
                value={storage}
                onChange={e => setStorage(Number(e.target.value))}
                className="w-full accent-foreground h-1.5 cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-muted-foreground mt-1">
                <span>0 Go</span><span>500 Go</span><span>1 To</span><span>1.5 To</span><span>2 To</span>
              </div>
            </div>

            <div>
              <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">Système d'exploitation</p>
              <PickerGrid items={OS_LIST} value={os} onChange={setOs} />
            </div>
          </SectionCard>

          {/* Options */}
          <SectionCard icon="🔧" title="Options & Services managés" sub="Activez les services additionnels">
            <div className="space-y-0 divide-y divide-border">
              {OPTIONS.map(opt => (
                <div key={opt.id} className="flex items-center justify-between py-3.5">
                  <div>
                    <p className="text-[13px] font-medium text-foreground">{opt.label}</p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{opt.sub}</p>
                    <p className={cn(
                      "text-[11px] font-medium mt-0.5",
                      opt.price === "Inclus" ? "text-muted-foreground" : "text-foreground"
                    )}>
                      {opt.price}
                    </p>
                  </div>
                  <Switch
                    checked={options[opt.id]}
                    onCheckedChange={v => setOptions(p => ({ ...p, [opt.id]: v }))}
                  />
                </div>
              ))}
            </div>
          </SectionCard>

          {/* Réseau */}
          <SectionCard icon="🔌" title="Réseau" sub="Configuration réseau et IP">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-[12px]">Réseau privé virtuel (VPC)</Label>
                <Select defaultValue="vpc-main">
                  <SelectTrigger className="h-8 text-[13px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vpc-main">vpc-prod-main (10.0.0.0/16)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px]">Sous-réseau</Label>
                <Select defaultValue="subnet-a">
                  <SelectTrigger className="h-8 text-[13px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="subnet-a">subnet-private-a (10.0.1.0/24)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[12px]">Groupe de sécurité</Label>
              <Select defaultValue="sg-backend">
                <SelectTrigger className="h-8 text-[13px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sg-backend">sg-backend (SSH, HTTP, HTTPS)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </SectionCard>

        </div>

        {/* Colonne droite — résumé sticky */}
        <div className="w-72 shrink-0 sticky top-[88px] space-y-3">
          <div className="border border-border rounded-2xl overflow-hidden">
            {/* Header résumé */}
            <div className="px-5 py-4 bg-foreground text-background">
              <p className="text-[10px] font-semibold uppercase tracking-widest opacity-60 mb-1">Résumé de commande</p>
              <p className="text-base font-semibold">Machines Virtuelles</p>
              <p className="text-[12px] opacity-60 mt-0.5">Cloud Privé · Compute</p>
            </div>

            {/* Lignes résumé */}
            <div className="px-5 py-4 space-y-2.5 bg-card border-b border-border">
              {[
                { label: "Plan",          value: "vCore M" },
                { label: "Compute",       value: "16 vCPU · 64 Go RAM" },
                { label: "Stockage base", value: "500 Go NVMe" },
                { label: "Région",        value: "🇫🇷 Paris · Zone A" },
                { label: "OS",            value: "Ubuntu 24.04 LTS" },
              ].map(row => (
                <div key={row.label} className="flex items-center justify-between">
                  <span className="text-[12px] text-muted-foreground">{row.label}</span>
                  <span className="text-[12px] font-medium text-foreground">{row.value}</span>
                </div>
              ))}
            </div>

            {/* Total */}
            <div className="px-5 py-4 bg-card">
              <div className="flex items-end justify-between">
                <div>
                  <p className="text-[11px] text-muted-foreground">Total mensuel</p>
                  <p className="text-[10px] text-muted-foreground">HT · Facturation mensuelle</p>
                </div>
                <p className="text-2xl font-semibold tabular-nums text-foreground">{total} €</p>
              </div>
              <Separator className="my-3 opacity-50" />
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] text-muted-foreground">
                  <span>Plan vCore M</span><span>{basePrice} €</span>
                </div>
                {storageAdd > 0 && (
                  <div className="flex justify-between text-[11px] text-muted-foreground">
                    <span>Stockage add. {storage} Go</span><span>+{storageAdd} €</span>
                  </div>
                )}
                {OPTIONS.filter(o => options[o.id] && o.price !== "Inclus").map(o => (
                  <div key={o.id} className="flex justify-between text-[11px] text-muted-foreground">
                    <span>{o.label.split(" ")[0]}</span>
                    <span>{o.price.replace("/mois","")}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <Button
            className="w-full h-9 text-[13px] font-medium"
            onClick={() => router.push("/dashboard/services/deploy/recapitulatif")}
          >
            Continuer vers le récapitulatif →
          </Button>
          <Button variant="ghost" className="w-full h-8 text-[12px] text-muted-foreground">
            Enregistrer comme brouillon
          </Button>

          <div className="border border-border rounded-xl px-4 py-3 text-[12px] text-muted-foreground bg-muted/20 flex items-start gap-2">
            <span className="text-emerald-500 shrink-0 mt-0.5">✓</span>
            SLA 99.96% garanti contractuellement
          </div>
        </div>

      </div>
    </SidebarInset>
  )
}