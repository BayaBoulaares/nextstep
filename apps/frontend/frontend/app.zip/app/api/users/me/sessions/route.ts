// src/app/api/users/me/sessions/route.ts
import { auth } from "@/auth"
import { NextResponse } from "next/server"

const API_URL = process.env.API_URL!

export async function GET() {
  const session = await auth()
  if (!session?.accessToken)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const res  = await fetch(`${API_URL}/api/users/me/sessions`, {
    headers: { Authorization: `Bearer ${session.accessToken}` },
  })
  const data = await res.json()

  // ✅ TEMPORAIRE — voir ce que Keycloak renvoie vraiment
  console.log("🔍 Sessions raw:", JSON.stringify(data, null, 2))

  return NextResponse.json(data, { status: res.status })
}