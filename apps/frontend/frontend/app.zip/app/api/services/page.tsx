"use client"

import { useState } from "react"
import { Plus, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog"
import { ServicesList } from "@/app/features/services/components/ServicesList"
import { ServiceForm  } from "@/app/features/services/components/ServiceForm"
import { useServices  } from "@/app/features/services/hooks/useService"
import { ApiError     } from "@/lib/apiClient"   // ✅ bonne source
import type { Service, CreateServiceDTO } from "@/app/features/services/types"

function getErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    switch (error.status) {
      case 401: return "Session expirée. Veuillez vous reconnecter."
      case 403: return "Vous n'avez pas les droits pour effectuer cette action."
      case 404: return "Service introuvable."
      case 409: return "Un service avec ce nom existe déjà."
      case 422: return "Les données saisies sont invalides."
      case 500: return "Erreur serveur. Veuillez réessayer plus tard."
      default:  return `Erreur inattendue (${error.status}).`
    }
  }
  if (error instanceof Error) return error.message
  return "Une erreur est survenue."
}

type FormMode = { type: "create" } | { type: "edit"; service: Service } | null

export default function ServicesPage() {
  const [formMode,    setFormMode]    = useState<FormMode>(null)
  const [errorBanner, setErrorBanner] = useState<string | null>(null)

  const {
    services,
    loading,
    error,
    createService,
    updateService,
    deleteService,
  } = useServices()

  const isOpen = formMode !== null
  const isEdit = formMode?.type === "edit"
  const closeForm = () => setFormMode(null)

  const handleSubmit = async (values: CreateServiceDTO) => {
    setErrorBanner(null)
    try {
      if (formMode?.type === "edit") {
        await updateService(formMode.service.id, values)
      } else {
        await createService(values)
      }
      closeForm()
    } catch (err: unknown) {
      setErrorBanner(getErrorMessage(err))
    }
  }

  const handleDelete = async (id: number) => {
    setErrorBanner(null)
    try {
      await deleteService(id)
    } catch (err: unknown) {
      setErrorBanner(getErrorMessage(err))
    }
  }

  const handleEdit = (id: number) => {
    const service = services.find((s: Service) => s.id === id)
    if (service) setFormMode({ type: "edit", service })
  }

  const defaultValues = isEdit
    ? {
        ...formMode.service,
        dureeEstimee: formMode.service.dureeEstimee != null
          ? String(formMode.service.dureeEstimee)
          : "",
      }
    : undefined

  return (
    <main className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-6 py-12 flex flex-col gap-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Services</h1>
            <p className="text-muted-foreground text-sm mt-1">
              {services.filter((s: Service) => s.actif).length} actif(s) · {services.length} au total
            </p>
          </div>
          <Button
            onClick={() => setFormMode({ type: "create" })}
            className="gap-2 rounded-full px-5 bg-black text-white hover:bg-gray-800"
          >
            <Plus className="h-4 w-4" /> Ajouter
          </Button>
        </div>

        {/* Bannière d'erreur */}
        {(error || errorBanner) && (
          <Alert variant="destructive" className="rounded-xl">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {errorBanner ?? (error || "Une erreur est survenue.")}
            </AlertDescription>
          </Alert>
        )}

        {/* Liste */}
        <ServicesList
          services={services}
          onEdit={handleEdit}
          onDelete={handleDelete}
          isLoading={loading}
        />

        {/* Dialog */}
        <Dialog open={isOpen} onOpenChange={(open) => { if (!open) closeForm() }}>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <div className="flex items-center gap-3">
                <div className={`h-7 w-1 rounded-full ${isEdit ? "bg-blue-500" : "bg-black"}`} />
                <DialogTitle>
                  {isEdit ? `Modifier : ${formMode.service.nom}` : "Nouveau service"}
                </DialogTitle>
              </div>
              <DialogDescription>
                {isEdit
                  ? "Modifiez les informations du service ci-dessous."
                  : "Remplissez les informations pour créer un nouveau service."}
              </DialogDescription>
            </DialogHeader>

            {isOpen && (
              <ServiceForm
                key={isEdit ? `edit-${formMode.service.id}` : "create"}
                onSubmit={handleSubmit}
                onCancel={closeForm}
                defaultValues={defaultValues}
                submitLabel={isEdit ? "Mettre à jour" : "Enregistrer"}
              />
            )}
          </DialogContent>
        </Dialog>

      </div>
    </main>
  )
}